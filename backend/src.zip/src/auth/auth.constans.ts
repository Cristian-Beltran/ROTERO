export const jwtConstants = {
  secret: 'B~AlDiVa*A3R?xipDN|Wy!Abr>KO9;kPfIeHdqnJjl^ET@oaB;wfeI_!<fMu2',
};
